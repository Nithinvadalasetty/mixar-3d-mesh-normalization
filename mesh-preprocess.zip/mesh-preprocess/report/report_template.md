# Final Report: Mesh Normalization, Quantization, and Error Analysis

## 1. Introduction
- Briefly describe your meshes and goals.

## 2. Methods
- Normalizations: Min–Max, Unit Sphere
- Quantization bins: 1024

## 3. Results
- Task 1 stats
- Task 2 screenshots/notes
- Task 3 error metrics + plots

## 4. Discussion
- Which normalization preserved structure best? Error patterns?

## 5. Conclusion

## 6. Reproduction
- Commands and environment
