import os
import argparse
import glob
import subprocess
import sys

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', type=str, default='data')
    parser.add_argument('--bins', type=int, default=1024)
    args = parser.parse_args()

    meshes = glob.glob(os.path.join(args.data_dir, '*.obj'))
    if not meshes:
        print('No .obj files found in', args.data_dir)
        sys.exit(0)

    for mesh in meshes:
        # Task 1 once per mesh
        subprocess.run([sys.executable, 'src/pipeline.py', '--mesh', mesh, '--task', '1'], check=True)
        for method in ['minmax', 'unit_sphere']:
            subprocess.run([sys.executable, 'src/pipeline.py', '--mesh', mesh, '--task', '2', '--method', method, '--bins', str(args.bins)], check=True)
            subprocess.run([sys.executable, 'src/pipeline.py', '--mesh', mesh, '--task', '3', '--method', method, '--bins', str(args.bins)], check=True)

    print('All tasks completed. See outputs/')

if __name__ == '__main__':
    main()
