# Mesh Preprocessing Starter Kit (Normalization, Quantization, Error Analysis)

This project helps you complete Task 1–3 of the assignment step-by-step.

## Folder Structure
mesh-preprocess/
- data/: Put your .obj files here
- outputs/: normalized/, quantized/, reconstructed/, plots/
- src/: io_utils.py, normalize.py, quantize.py, error_metrics.py, visualize.py, pipeline.py
- notebooks/: analysis.ipynb
- report/: report_template.md
- run_all.py, requirements.txt, README.md

## Quickstart
1) pip install -r requirements.txt
2) Put your .obj files inside data/
3) Task 1: python src/pipeline.py --mesh data/your_mesh.obj --task 1
4) Task 2: python src/pipeline.py --mesh data/your_mesh.obj --task 2 --method minmax --bins 1024
           python src/pipeline.py --mesh data/your_mesh.obj --task 2 --method unit_sphere --bins 1024
5) Task 3: python src/pipeline.py --mesh data/your_mesh.obj --task 3 --method minmax --bins 1024
           python src/pipeline.py --mesh data/your_mesh.obj --task 3 --method unit_sphere --bins 1024
6) All meshes: python run_all.py --bins 1024

Notes: Matplotlib only, one chart per figure, no custom colors.
