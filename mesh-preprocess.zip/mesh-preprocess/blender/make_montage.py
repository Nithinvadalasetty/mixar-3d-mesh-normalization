﻿import os, json
from PIL import Image, ImageDraw

BASE = r"C:\Users\vnith\OneDrive\Desktop\mesh-preprocess"
IN_DIR = os.path.join(BASE, "outputs", "renders")
OUT_DIR = os.path.join(IN_DIR, "montages")
PLOTS_DIR = os.path.join(BASE, "outputs", "plots")
os.makedirs(OUT_DIR, exist_ok=True)

MESHLIST = ["cube","sphere","torus","cylinder","cone"]

def load(p):
    return Image.open(p).convert("RGB") if os.path.exists(p) else Image.new("RGB",(1024,1024),(240,240,240))

def montage(mesh):
    d = os.path.join(IN_DIR, mesh)
    a = load(os.path.join(d,"original.png"))
    b = load(os.path.join(d,"normalized_minmax.png"))
    c = load(os.path.join(d,"quantized_minmax_q1024.png"))
    e = load(os.path.join(d,"reconstructed_minmax_q1024.png"))
    W,H=a.size
    canvas = Image.new("RGB",(W*2,H*2+80),(255,255,255))
    draw = ImageDraw.Draw(canvas)
    draw.text((20,10), f"Mesh: {mesh}", fill=(0,0,0))
    canvas.paste(a,(0,80)); canvas.paste(b,(W,80)); canvas.paste(c,(0,80+H)); canvas.paste(e,(W,80+H))
    out = os.path.join(OUT_DIR, f"montage_{mesh}.png"); canvas.save(out); print("[OK] montage ->", out)
    # comparison sheet
    j = os.path.join(PLOTS_DIR, f"{mesh}_minmax_q1024_errors.json")
    if os.path.exists(j):
        with open(j,"r") as f: data=json.load(f)
        head = Image.new("RGB",(W*2,120),(255,255,255))
        d2 = ImageDraw.Draw(head)
        txt = f"MSE: {data.get('mse')} | MAE: {data.get('mae')} | MSE_axis: {data.get('mse_axis')} | MAE_axis: {data.get('mae_axis')}"
        d2.text((20,20), txt, fill=(0,0,0))
        sheet = Image.new("RGB",(W*2,H*2+120),(255,255,255))
        sheet.paste(head,(0,0))
        sheet.paste(a,(0,120)); sheet.paste(b,(W,120)); sheet.paste(c,(0,120+H)); sheet.paste(e,(W,120+H))
        out2 = os.path.join(OUT_DIR, f"comparison_{mesh}.png"); sheet.save(out2); print("[OK] comparison ->", out2)

def main():
    for m in MESHLIST: montage(m)

if __name__=="__main__": main()
