﻿import bpy, math, os, mathutils, addon_utils

BASE = r"C:\Users\vnith\OneDrive\Desktop\mesh-preprocess"
MESHES = ["cube","sphere","torus","cylinder","cone"]
SIZE = 1024

def enable_import_addons():
    for m in ("io_scene_obj","io_mesh_ply"):
        try:
            addon_utils.enable(m, default_set=True, persistent=True)
            print("[ADDON] enabled", m)
        except Exception as e:
            print("[ADDON][ERR]", m, e)

def setup():
    bpy.ops.wm.read_homefile(use_empty=True)
    enable_import_addons()
    s = bpy.context.scene
    s.render.engine = 'BLENDER_EEVEE'
    s.render.resolution_x = SIZE
    s.render.resolution_y = SIZE
    s.render.film_transparent = False
    # white bg
    w = bpy.data.worlds.new("White"); s.world = w; w.use_nodes = True
    w.node_tree.nodes["Background"].inputs[0].default_value = (1,1,1,1)
    w.node_tree.nodes["Background"].inputs[1].default_value = 1.0
    # camera
    cam = bpy.data.cameras.new("Cam")
    cam_obj = bpy.data.objects.new("Cam", cam)
    bpy.context.collection.objects.link(cam_obj)
    s.camera = cam_obj
    cam_obj.location = (0, -4.5, 2.8)
    cam_obj.rotation_euler = (math.radians(65), 0, 0)
    # lights
    L = bpy.data.lights.new("Key", type='AREA'); L.energy=2000; L.size=4; L.size_y=4
    key = bpy.data.objects.new("Key", L); bpy.context.collection.objects.link(key); key.location=(3,4,5)
    L2 = bpy.data.lights.new("Fill", type='POINT'); L2.energy=800
    fill = bpy.data.objects.new("Fill", L2); bpy.context.collection.objects.link(fill); fill.location=(-3,-2,2)
    L3 = bpy.data.lights.new("Rim", type='SPOT'); L3.energy=1200; L3.spot_size=math.radians(45)
    rim = bpy.data.objects.new("Rim", L3); bpy.context.collection.objects.link(rim); rim.location=(0,-5,4)

def import_any(path):
    if not os.path.exists(path):
        print("[MISS]", path); return []
    ext = os.path.splitext(path)[1].lower()
    for o in bpy.context.selected_objects: o.select_set(False)
    try:
        if ext==".obj":
            print("[IMP][OBJ]", path)
            bpy.ops.import_scene.obj(filepath=path)
        elif ext==".ply":
            print("[IMP][PLY]", path)
            bpy.ops.import_mesh.ply(filepath=path)
        else:
            print("[SKIP] unsupported", path); return []
    except Exception as e:
        print("[ERR][IMPORT]", path, e); return []
    sel = [o for o in bpy.context.selected_objects] or [o for o in bpy.context.scene.objects if o.type=='MESH']
    print("[IMP][OK] objects:", len(sel))
    return sel

def bbox(objects):
    mins = mathutils.Vector((1e9,1e9,1e9)); maxs = mathutils.Vector((-1e9,-1e9,-1e9))
    for o in objects:
        if o.type!='MESH': continue
        for v in o.bound_box:
            w = o.matrix_world @ mathutils.Vector(v)
            mins.x=min(mins.x,w.x); mins.y=min(mins.y,w.y); mins.z=min(mins.z,w.z)
            maxs.x=max(maxs.x,w.x); maxs.y=max(maxs.y,w.y); maxs.z=max(maxs.z,w.z)
    return mins, maxs

def center_scale(objects, target=2.0):
    mins,maxs = bbox(objects); c=(mins+maxs)*0.5; size=(maxs-mins)
    m = max(size.x,size.y,size.z,1e-6); s = target/m
    for o in objects:
        o.location -= c; o.scale *= s
    bpy.context.view_layer.update()

def assign_mat(objects):
    mat = bpy.data.materials.new("Neutral"); mat.use_nodes=True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (0.8,0.8,0.8,1)
    bsdf.inputs["Roughness"].default_value = 0.35
    for o in objects:
        if o.type=='MESH':
            if not o.data.materials: o.data.materials.append(mat)
            else: o.data.materials[0]=mat

def rm_meshes():
    bpy.ops.object.select_all(action='DESELECT')
    for o in list(bpy.context.scene.objects):
        if o.type=='MESH': o.select_set(True)
    bpy.ops.object.delete()

def render_one(in_path, out_path):
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    rm_meshes()
    obs = import_any(in_path)
    if not obs:
        print("[SKIP] nothing to render for", in_path); return
    center_scale(obs,2.0); assign_mat(obs)
    bpy.context.scene.render.filepath = out_path
    bpy.ops.render.render(write_still=True)
    print("[OK][RENDER]", out_path)

def main():
    setup()
    for name in MESHES:
        print("\\n=== Rendering:", name, "===")
        outdir = os.path.join(BASE, "outputs", "renders", name)
        p_orig = os.path.join(BASE, "data", name + ".obj")
        p_norm = os.path.join(BASE, "outputs", "normalized", name + "_minmax_norm.obj")
        p_quant = os.path.join(BASE, "outputs", "quantized", name + "_minmax_q1024.ply")
        p_recon = os.path.join(BASE, "outputs", "reconstructed", name + "_minmax_q1024_recon.obj")
        render_one(p_orig,  os.path.join(outdir,"original.png"))
        render_one(p_norm,  os.path.join(outdir,"normalized_minmax.png"))
        render_one(p_quant, os.path.join(outdir,"quantized_minmax_q1024.png"))
        render_one(p_recon, os.path.join(outdir,"reconstructed_minmax_q1024.png"))

if __name__ == "__main__":
    main()
