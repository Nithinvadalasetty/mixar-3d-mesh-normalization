from typing import Tuple, Dict
import numpy as np

def minmax_normalize(vertices: np.ndarray) -> Tuple[np.ndarray, Dict]:
    vmin = vertices.min(axis=0)
    vmax = vertices.max(axis=0)
    scale = (vmax - vmin)
    scale[scale == 0] = 1.0
    norm = (vertices - vmin) / scale
    meta = {'type': 'minmax', 'vmin': vmin.tolist(), 'vmax': vmax.tolist()}
    return norm, meta

def minmax_denormalize(norm_vertices: np.ndarray, meta: Dict) -> np.ndarray:
    vmin = np.array(meta['vmin'], dtype=float)
    vmax = np.array(meta['vmax'], dtype=float)
    scale = (vmax - vmin)
    scale[scale == 0] = 1.0
    return norm_vertices * scale + vmin

def unit_sphere_normalize(vertices: np.ndarray) -> Tuple[np.ndarray, Dict]:
    center = vertices.mean(axis=0)
    centered = vertices - center
    max_radius = np.linalg.norm(centered, axis=1).max()
    if max_radius == 0:
        max_radius = 1.0
    norm = centered / max_radius
    norm_01 = (norm + 1.0) / 2.0
    meta = {'type': 'unit_sphere', 'center': center.tolist(), 'max_radius': float(max_radius)}
    return norm_01, meta

def unit_sphere_denormalize(norm01_vertices: np.ndarray, meta: Dict) -> np.ndarray:
    norm = (norm01_vertices * 2.0) - 1.0
    center = np.array(meta['center'], dtype=float)
    max_radius = float(meta['max_radius'])
    return norm * max_radius + center
