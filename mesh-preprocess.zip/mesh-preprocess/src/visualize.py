import os
import numpy as np
import matplotlib.pyplot as plt

def plot_error_per_axis(mse_axis, mae_axis, title, out_png):
    plt.figure()
    axes = ['x', 'y', 'z']
    idx = np.arange(3)
    width = 0.35
    plt.bar(idx - width/2, mse_axis, width, label='MSE')
    plt.bar(idx + width/2, mae_axis, width, label='MAE')
    plt.xticks(idx, axes)
    plt.title(title)
    plt.legend()
    os.makedirs(os.path.dirname(out_png), exist_ok=True)
    plt.savefig(out_png, dpi=180, bbox_inches='tight')
    plt.close()

def plot_hist_1d(values, title, out_png, bins=50):
    plt.figure()
    plt.hist(values, bins=bins)
    plt.title(title)
    os.makedirs(os.path.dirname(out_png), exist_ok=True)
    plt.savefig(out_png, dpi=180, bbox_inches='tight')
    plt.close()
