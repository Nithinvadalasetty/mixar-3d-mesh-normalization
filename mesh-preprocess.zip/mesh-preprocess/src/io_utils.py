import os
import json
from typing import Tuple, Dict
import numpy as np
import trimesh

def load_mesh_vertices(mesh_path: str) -> Tuple[np.ndarray, trimesh.Trimesh]:
    mesh = trimesh.load(mesh_path, force='mesh')
    if not isinstance(mesh, trimesh.Trimesh):
        mesh = mesh.dump(concatenate=True)
    vertices = mesh.vertices.view(np.ndarray)
    return vertices, mesh

def save_mesh_with_vertices(ref_mesh: trimesh.Trimesh, vertices: np.ndarray, out_path: str) -> None:
    m = ref_mesh.copy()
    m.vertices = vertices
    m.export(out_path)

def save_stats(stats: Dict, out_json_path: str) -> None:
    os.makedirs(os.path.dirname(out_json_path), exist_ok=True)
    with open(out_json_path, 'w') as f:
        json.dump(stats, f, indent=2, sort_keys=True)

def basic_vertex_stats(vertices: np.ndarray) -> dict:
    stats = {
        'num_vertices': int(vertices.shape[0]),
        'min': vertices.min(axis=0).tolist(),
        'max': vertices.max(axis=0).tolist(),
        'mean': vertices.mean(axis=0).tolist(),
        'std': vertices.std(axis=0).tolist(),
    }
    return stats
