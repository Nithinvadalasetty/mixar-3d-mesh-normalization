import numpy as np

def mse(original: np.ndarray, reconstructed: np.ndarray) -> float:
    return float(np.mean((original - reconstructed) ** 2))

def mae(original: np.ndarray, reconstructed: np.ndarray) -> float:
    return float(np.mean(np.abs(original - reconstructed)))

def per_axis_metrics(original: np.ndarray, reconstructed: np.ndarray):
    diff = reconstructed - original
    mse_axis = np.mean(diff**2, axis=0)
    mae_axis = np.mean(np.abs(diff), axis=0)
    return mse_axis.tolist(), mae_axis.tolist()
