import os
import argparse
import numpy as np
from io_utils import load_mesh_vertices, save_mesh_with_vertices, save_stats, basic_vertex_stats
from normalize import minmax_normalize, minmax_denormalize, unit_sphere_normalize, unit_sphere_denormalize
from quantize import quantize, dequantize
from error_metrics import mse, mae, per_axis_metrics
from visualize import plot_error_per_axis

def task1(mesh_path, out_dir):
    vertices, mesh = load_mesh_vertices(mesh_path)
    stats = basic_vertex_stats(vertices)
    base = os.path.splitext(os.path.basename(mesh_path))[0]
    save_stats(stats, os.path.join(out_dir, 'plots', f'{base}_stats.json'))
    print('Task 1 — Stats:', stats)

def run_norm_quant(method, vertices, mesh, out_dir, base, bins):
    if method == 'minmax':
        norm, meta = minmax_normalize(vertices)
        denorm_fn = minmax_denormalize
    elif method == 'unit_sphere':
        norm, meta = unit_sphere_normalize(vertices)
        denorm_fn = unit_sphere_denormalize
    else:
        raise ValueError('Unknown method')

    norm_mesh_path = os.path.join(out_dir, 'normalized', f'{base}_{method}_norm.obj')
    save_mesh_with_vertices(mesh, norm, norm_mesh_path)

    q = quantize(norm, bins=bins)
    dq = dequantize(q, bins=bins)
    quant_mesh_path = os.path.join(out_dir, 'quantized', f'{base}_{method}_q{bins}.ply')
    save_mesh_with_vertices(mesh, dq, quant_mesh_path)

    return norm, meta, denorm_fn, q

def task2(mesh_path, out_dir, method, bins):
    vertices, mesh = load_mesh_vertices(mesh_path)
    base = os.path.splitext(os.path.basename(mesh_path))[0]
    _norm, _meta, _denorm, _q = run_norm_quant(method, vertices, mesh, out_dir, base, bins)
    print(f'Task 2 — Saved normalized and quantized meshes for method={method}')

def task3(mesh_path, out_dir, method, bins):
    vertices, mesh = load_mesh_vertices(mesh_path)
    base = os.path.splitext(os.path.basename(mesh_path))[0]

    norm, meta, denorm_fn, q = run_norm_quant(method, vertices, mesh, out_dir, base, bins)

    dq = dequantize(q, bins=bins)
    recon = denorm_fn(dq, meta)

    recon_path = os.path.join(out_dir, 'reconstructed', f'{base}_{method}_q{bins}_recon.obj')
    save_mesh_with_vertices(mesh, recon, recon_path)

    m = mse(vertices, recon)
    a = mae(vertices, recon)
    mse_axis, mae_axis = per_axis_metrics(vertices, recon)

    stats = {
        'method': method,
        'bins': bins,
        'mse': m,
        'mae': a,
        'mse_axis': mse_axis,
        'mae_axis': mae_axis
    }
    save_stats(stats, os.path.join(out_dir, 'plots', f'{base}_{method}_q{bins}_errors.json'))
    print('Task 3 — Errors:', stats)

    plot_png = os.path.join(out_dir, 'plots', f'{base}_{method}_q{bins}_errors.png')
    plot_error_per_axis(mse_axis, mae_axis, f'Errors per axis ({method}, bins={bins})', plot_png)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mesh', type=str, required=True, help='Path to .obj file')
    parser.add_argument('--task', type=int, choices=[1,2,3], required=True, help='Task number to run')
    parser.add_argument('--method', type=str, default='minmax', choices=['minmax','unit_sphere'], help='Normalization method')
    parser.add_argument('--bins', type=int, default=1024, help='Quantization bins')
    parser.add_argument('--out', type=str, default='outputs', help='Output directory')
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)

    if args.task == 1:
        task1(args.mesh, args.out)
    elif args.task == 2:
        task2(args.mesh, args.out, args.method, args.bins)
    elif args.task == 3:
        task3(args.mesh, args.out, args.method, args.bins)

if __name__ == '__main__':
    main()
