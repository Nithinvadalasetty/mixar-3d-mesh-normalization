import numpy as np

def quantize(norm_vertices: np.ndarray, bins: int = 1024) -> np.ndarray:
    clipped = np.clip(norm_vertices, 0.0, 1.0)
    q = np.floor(clipped * (bins - 1)).astype(np.int32)
    return q

def dequantize(q_vertices: np.ndarray, bins: int = 1024) -> np.ndarray:
    return q_vertices.astype(np.float64) / float(bins - 1)
